# Handoff: Cubic CM Project Document Templates

## Overview
Eight A4 project forms for **Cubic Construction Management** (ABN 32 161 357 142), plus an
index page. Currently blank printable forms; the task is to make the construction management
system **generate them populated from project data**, render to screen, and export to PDF.

Jurisdiction: Australia (NSW default). Currency AUD, GST 10%. Paper A4.

## About the Design Files
`templates/` holds the **design reference** — working HTML showing exact layout, wording and
print geometry. Recreate these as server- or client-rendered templates inside your existing
stack (React/Vue/Blade/Razor — whatever the app uses). Do not copy the files in wholesale:
they carry a design-tool runtime (`support.js`) your app does not need.

**`assets/ccm-logo-blue.png` and the wording ARE production content** — use verbatim.

## Fidelity
**High fidelity on print geometry, letterhead and legal wording.** Clause text in the
Subcontract Agreement is legally reviewed copy — reproduce character for character, including
clause numbers (note: the source skips 3.13 and 17.4 — keep those gaps, do not renumber).
Layout spacing may adapt to your component library so long as A4 pagination is preserved.

---

## Design Tokens

| Token | Value | Use |
|---|---|---|
| `--ccm-navy` | `#2A3580` | Table headers, section headings, letterhead rule, primary buttons |
| `--ccm-navy-dark` | `#1A2360` | Hover / link active |
| `--ccm-ink` | `#1D2330` | Body text, H1 |
| `--ccm-body` | `#3A4152` | Legal notes, fine print |
| `--ccm-muted` | `#6E7480` | Letterhead detail, footer, eyebrow labels |
| `--ccm-muted-light` | `#8A90A0` | Index eyebrow labels |
| `--ccm-placeholder` | `#9AA0AC` | Stamp-area label, empty-cell hints |
| `--ccm-line` | `#C9CDD6` | Table borders (1px), footer rule |
| `--ccm-line-light` | `#DEE1E8` | Index card borders |
| `--ccm-fill` | `#F4F5F8` | Label-cell background, total rows |

### Typography
**Archivo** (400/500/600/700) throughout — Google Fonts, OFL, self-host for offline use.

| Element | Spec |
|---|---|
| H1 document title | 19pt / 700 / `letter-spacing:-0.01em` / `--ccm-ink` |
| Eyebrow under H1 | 9pt / 600 / `0.14em` / uppercase / `--ccm-muted` |
| H2 section heading | 11pt / 700 / `0.08em` / uppercase / `--ccm-navy` |
| Clause sub-heading | 9.5pt / 700 / `--ccm-ink` |
| Body / clause text | 9.5–10.5pt / 400 / `line-height:1.6` |
| Table `th` | 8.5pt / 600 / `0.06em` / uppercase / white on `--ccm-navy` |
| Table `td` | 9.5–10pt / `padding:7px 9px` / `1px solid --ccm-line` / `vertical-align:top` |
| Letterhead company line | 8pt / 600 / `0.02em` / `--ccm-navy` / `white-space:nowrap` |
| Letterhead detail lines | 7.5pt / 400 / `line-height:1.5` / `--ccm-muted` |
| Footer | 7.5pt / `--ccm-muted` |

Minimum body size is **9pt** — do not go smaller on any form.

---

## Page Furniture (identical on every form)

### Letterhead (repeats on every printed page)
Flex row, `align-items:flex-end`, `justify-content:space-between`, `gap:24px`,
`padding-bottom:8px`, `border-bottom:2px solid #2A3580`, `margin-bottom:18px`.
- **Left:** logo, `width:152px; height:auto; display:block`.
- **Right:** right-aligned block — `CUBIC CONSTRUCTION MANAGEMENT` / `ABN 32 161 357 142` /
  `Unit 3, 5 Bessemer Street, Blacktown NSW 2148` / `0410 543 828 · <dept email> · cubiccm.com`.
  Department email varies by form: `gordon@cubiccm.com` default, `accounts@cubiccm.com` on the
  Tax Invoice.

Reserved band height: **1.15in** portrait, **1.05in** landscape.

### Footer (repeats on every printed page)
Flex row `space-between`, `padding-top:6px`, `border-top:1px solid #C9CDD6`, 7.5pt muted.
Three cells: `<Form name> · Ref <DOC-REF> · Rev <n>` | context note | `Page x of y`.
Reserved band height: **0.42in** portrait, **0.4in** landscape.

### Document reference scheme
`CCM-<TYPE>-<seq>` — `SC` subcontract, `INV` invoice, `VO` variation, `SI` site instruction,
`RFI`, `EOT`, `PR` progress report, `DEF` defect report. Sequence is 4-digit, per project.
Every form also carries **Rev** and issue date. The system must own reference allocation —
these are the audit keys.

### Standard header fields
Every form opens with a particulars table: label cells `background:#F4F5F8; font-weight:600`,
value cells blank. Common fields: Project, Contract No., issue date, and the form's own number.
Populate all of these from the project record — none should print blank.

---

## Forms

| Form | Ref | Pages | Orientation | Purpose |
|---|---|---|---|---|
| Subcontract Agreement | CCM-SC | ~10 | Portrait | Formal instrument + Annexure A terms (clauses 1–17) + Appendix A |
| Tax Invoice / Progress Claim | CCM-INV | 1 | Portrait | Progress payment claim under SOP Act |
| Variation Order | CCM-VO | 1 | Portrait | Priced instruction to vary, dual signature |
| Site Instruction | CCM-SI | 1 | Portrait | Written site direction, acknowledged |
| Request for Information | CCM-RFI | 2 | Portrait | Query p1, consultant response p2 |
| Extension of Time Claim | CCM-EOT | 2 | Portrait | Delay notice + Superintendent determination |
| Monthly Progress Report | CCM-PR | 2 | Portrait | Status dashboard, WHS, cost, photos |
| Defect List Report | CCM-DEF | n | **Landscape** | 8 defects per sheet with photo cell |

### 1. Subcontract Agreement
Sections: particulars / 1 Parties / 2 Subcontract Works / 3 Commercial Terms / 4 Programme /
Insurances / Subcontract Documents / Special Conditions / Execution — then **Annexure A**
(clauses 1–17) on a fresh page, and **Appendix A** legislative reference.

Annexure A structure (reproduce verbatim from `templates/Subcontract Agreement.dc.html`):
1 Definitions & Interpretation · 2 Subcontract Works · 3 Contract Sum and Payment ·
4 Time (EOT, LDs, acceleration) · 5 Variations · 6 WHS · 7 Insurance · 8 Latent Conditions ·
9 Defects and Defects Liability · 10 Suspension and Termination · 11 Indemnity and Liability ·
12 Dispute Resolution · 13 Intellectual Property · 14 Personal Property Securities ·
15 Sub-Subcontracting · 16 Working Hours · 17 General Provisions.

Clause values the system must inject (they are currently blanks or hard-coded):
`Contract Sum`, `retention % and cap`, `payment terms (days)`, `liquidated damages rate`
(template says `$500 AUD/day` — make configurable), `Date for Completion`, `DLP months`,
`working hours` (template: Mon–Fri 7:00–15:30, Sat 7:00–12:30), `clause 10.7 notice period`
(currently literal `[Insert]` — **must be resolved before issue**), insurance minimums per
Schedule 1, and the SOP Act name for the Site's State.

Defect classification is a fixed three-row table (Urgent / Major / Minor) with contractual
response times 24h / 10 BD / 15 BD and statutory warranties 6–10y / 6y / 2y. Drive your
defect-management module's SLA from this table.

### 2. Tax Invoice / Progress Claim
- Header right: bordered amount-payable panel — 7.5pt uppercase label, **20pt/700 navy** total,
  8pt due date.
- Claim table columns: Item / Description / Contract value / % complete / Value to date /
  Previously claimed / **This claim** (all money right-aligned), then a filled subtotal row.
  Standard rows: original contract works, approved variations, provisional sums adjustment,
  materials on site (unfixed).
- Two side-by-side blocks: approved-variations schedule (VO No. / Description / Value) and a
  **Summary** ladder — claimed this period, less retention %, less back charges, net excl. GST,
  GST 10%, **Total payable** (white on navy row).
- Payment details + a Security of Payment notice cell. The Act named must follow the Site's
  jurisdiction — see the table at the end of this doc.

Calculation rules: `this claim = value to date − previously claimed`; retention applies to the
period claim, capped at the subcontract cap; GST = 10% of net after deductions; round to cents.

### 3. Variation Order
Bordered `VO-0000` badge top right. Description / reason / documents referenced, then a price
breakdown (labour hrs, materials, plant, sub-quotes) → subtotal → **O&P %** → net excl. GST →
GST → total (navy row). Then effect on contract sum (before / this variation / adjusted) and on
the Date for Practical Completion, with an EOT cross-reference. Closing rule: no varied work
before both signatures.

### 4. Site Instruction
`SI-0000` badge with date **and time**. Nature-of-instruction checkbox row, a large instruction
body, then cost/time implications — including "does this involve a variation?", the VO
reference, and a deadline to submit a price (`_____ business days`). Dual signature with
date **and time** on both sides.

### 5. Request for Information
Page 1: particulars (incl. discipline + priority), documents-referenced table (drawing / number
/ revision / detail reference), question, proposed solution, impact-if-unanswered (activity,
programme days, cost, attachments).
Page 2: response block with responder + date, then flags — response constitutes a variation
(VO ref), revised documents issued, EOT applies (EOT ref), status Open/Answered/Closed with
date closed. Log RFI open and close dates in the register automatically.

### 6. Extension of Time Claim
Delay-event particulars (occurred / became known / continuing / ceased, category checkboxes,
description), a **programme-impact table** (activity, activity ID, planned finish, revised
finish, critical path?, delay days), current vs sought Date for Practical Completion, float
absorbed, mitigation, then a delay-cost table (preliminaries, supervision, plant standing,
subcontractor delay costs). Attachments checklist. Ends with a Superintendent determination
panel: approved full / part / rejected / more info, days granted, reasons, signature.

Pull activity IDs and planned dates straight from the programme; compute delay days rather
than asking for them.

### 7. Monthly Progress Report
Sections: 1 status at a glance (planned / actual / variance / status per measure) · 2 executive
summary · 3 work completed · 4 planned next period · 5 programme and delays (with EOT refs) ·
6 cost and variations · 7 WHS metrics (this period / project to date) · 8 quality, defects, RFIs
· 9 risks and issues · 10 four site photographs, 2×2 grid, 150px cells with caption lines.

Every table here is derivable from other modules — the report should be **generated, not typed**:
progress from the programme, section 6 from the variation register, 7 from the WHS log,
8 from the RFI and defect registers, 5 from the EOT register.

The reference build has an **AI drafting** control on the executive summary: it reads the
populated sections and drafts 2–3 paragraphs (progress vs programme, work completed, delay and
cost exposure, safety, decisions needed from the client), grounded strictly in the entered
figures — never inventing numbers, silent on blank fields. Reproduce with your own LLM call if
wanted; the system prompt is in the logic class of the reference file. Keep it advisory: the
draft lands in an editable field and a human signs off.

### 8. Defect List Report — landscape
Header shows **Open / Closed / Total** counters in three bordered boxes.
Row columns: No. / Location / Defect description / Trade-subcontractor / Priority (H·M·L) /
Date raised / Due date / Status / Verified by-date / **Photo** (84px cell, `padding:3px`).
Eight rows per sheet, paginate beyond that. Below: priority key (H = safety/watertightness/
compliance, 48h · M = functional/finish, by next inspection · L = cosmetic, before PC) and the
back-charge note.

Due dates should be computed from priority + the Annexure A clause 9.7 response times, not
entered by hand.

---

## Interactions & Behavior
- **Fillable cells:** blank data cells are `contenteditable` on screen; label cells
  (`#F4F5F8` background) are not. Focus ring `2px solid #2A3580`, `outline-offset:-2px`.
  Empty cells may show an 8.5pt `#B4B9C4` placeholder.
- **E-signature:** `signature-pad` — a pointer-drawn canvas, 52px tall inside a
  `1px solid #C9CDD6` box, `#14232E` stroke at `lineWidth:1.6`, round caps, DPR-aware.
  Hover reveals a **Clear** button; the drawn image persists and prints as drawn. Present on
  Variation Order, Site Instruction and the Subcontract Agreement execution block. Block order
  is **Signature → Full name → Position → Date**.
  In production, replace localStorage persistence with a signed audit record: signer identity,
  timestamp, IP/device, document hash, and the signature raster. Electronic signatures are
  accepted under clause 17.9 — but the audit trail is what makes them defensible.
- **Screen-only controls** carry `data-noprint` → `display:none` at print.
- **Photo cells** accept drag-and-drop images and keep aspect fill.
- No animation anywhere. These are documents.

## Print / PDF
Portrait forms: A4, margin `0.6in`, header band `1.15in`, footer band `0.42in`.
Landscape (Defect List): A4 landscape, margin `0.5in`, header `1.05in`, footer `0.4in`.
Header and footer repeat on every printed page; content flows and paginates between them.
Deliberate page breaks: Subcontract Agreement before Annexure A and before Appendix A;
Progress Report before section 5; RFI before the response page.

Do not let your framework inject its own print margins, headers or URL/date chrome.
Export must be silent, A4, one continuous flow.

## State Management
Per document: draft / issued / acknowledged / closed, revision number, reference number,
signature records, and links to the project, contract and (where relevant) the parent RFI,
VO, EOT or defect. Revisions are immutable once issued — issue Rev 1, never edit Rev 0.

## Cross-form data flow
- Site Instruction → Variation Order (when the instruction is varied work)
- RFI response → Variation Order and/or EOT
- Variation Order → Tax Invoice variations schedule, and the adjusted contract sum
- EOT → revised Date for Practical Completion → liquidated-damages calculation
- Defect List → Progress Report section 8, and retention release gating (clause 9.8)
- Subcontract Agreement clause 9.7 → defect due-date SLAs

## Jurisdiction table — Security of Payment Act by State
| State | Act |
|---|---|
| NSW | Building and Construction Industry Security of Payment Act 1999 |
| VIC | Building and Construction Industry Security of Payment Act 2002 |
| QLD | Building Industry Fairness (Security of Payment) Act 2017 |
| SA | Building and Construction Industry Security of Payment Act 2009 |
| WA | Construction Contracts Act 2004 |
| ACT | Building and Construction Industry (Security of Payment) Act 2009 |
| TAS | Building and Construction Industry Security of Payment Act 2009 |
| NT | Construction Contracts (Security of Payments) Act 2004 |

Select by Site location, not by company address. The Act name, claim wording and statutory
timeframes all follow from it.

## Assets
| File | Notes |
|---|---|
| `assets/ccm-logo-blue.png` | Letterhead logo — 152px wide in use |

## Screenshots
`screenshots/00-index.png` — the form index as rendered.

## Files
`templates/` — the nine reference documents plus their runtime helpers
(`doc-page.js` print shell, `image-slot.js` photo cells, `signature-pad.js` e-signature,
`support.js` design-tool runtime — not needed in production). Open
`templates/Document Templates.dc.html` in a browser to reach all eight forms.

## Caveat
The Subcontract Agreement wording is a commercial form, not legal advice. Clause 10.7 still
contains `[Insert]`. Have a lawyer review the terms and any special conditions before the
system issues them to subcontractors.
