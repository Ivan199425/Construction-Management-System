(function () {
  if (customElements.get('signature-pad')) return;

  const KEY = (id) => 'ccm-sig:' + id;

  class SignaturePad extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      const label = this.getAttribute('label') || 'Sign here';
      const id = this.getAttribute('id') || label;
      this._id = id;

      const root = this.attachShadow({ mode: 'open' });
      root.innerHTML = `
        <style>
          :host { display:block; position:relative; }
          .wrap { position:relative; height:100%; min-height:64px; background:#fff; cursor:crosshair; }
          canvas { display:block; width:100%; height:100%; touch-action:none; }
          .hint {
            position:absolute; inset:auto 0 6px 0; text-align:center; pointer-events:none;
            font:400 8pt/1 Archivo, system-ui, sans-serif; color:#B4B9C4; letter-spacing:0.08em;
            text-transform:uppercase;
          }
          .hint.hidden { display:none; }
          .tools {
            position:absolute; top:3px; right:4px; display:flex; gap:4px; opacity:0; transition:opacity .12s;
          }
          .wrap:hover .tools, .wrap:focus-within .tools { opacity:1; }
          button {
            font:600 7pt/1 Archivo, system-ui, sans-serif; letter-spacing:0.06em; text-transform:uppercase;
            color:#6E7480; background:#F4F5F8; border:1px solid #C9CDD6; border-radius:2px;
            padding:3px 6px; cursor:pointer;
          }
          button:hover { color:#2A3580; border-color:#2A3580; }
          @media print { .tools { display:none; } .hint { display:none; } }
        </style>
        <div class="wrap">
          <canvas></canvas>
          <div class="hint">${label}</div>
          <div class="tools"><button type="button">Clear</button></div>
        </div>`;

      this._canvas = root.querySelector('canvas');
      this._hint = root.querySelector('.hint');
      root.querySelector('button').addEventListener('click', () => this.clear());

      this._resize();
      this._restore();
      this._bind();

      if (window.ResizeObserver) {
        this._ro = new ResizeObserver(() => this._resize(true));
        this._ro.observe(this);
      }
    }

    disconnectedCallback() { if (this._ro) this._ro.disconnect(); }

    _resize(keep) {
      const c = this._canvas;
      const dpr = Math.min(window.devicePixelRatio || 1, 3);
      const w = this.clientWidth || 300;
      const h = this.clientHeight || 64;
      if (c.width === Math.round(w * dpr) && c.height === Math.round(h * dpr)) return;
      const prior = keep && this._hasInk ? c.toDataURL('image/png') : null;
      c.width = Math.round(w * dpr);
      c.height = Math.round(h * dpr);
      const ctx = c.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineWidth = 1.6;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = '#14232E';
      this._ctx = ctx;
      if (prior) this._draw(prior);
    }

    _bind() {
      const c = this._canvas;
      let drawing = false;
      const pos = (e) => {
        const r = c.getBoundingClientRect();
        return [e.clientX - r.left, e.clientY - r.top];
      };
      c.addEventListener('pointerdown', (e) => {
        drawing = true;
        c.setPointerCapture(e.pointerId);
        const [x, y] = pos(e);
        this._ctx.beginPath();
        this._ctx.moveTo(x, y);
        this._ink();
      });
      c.addEventListener('pointermove', (e) => {
        if (!drawing) return;
        const [x, y] = pos(e);
        this._ctx.lineTo(x, y);
        this._ctx.stroke();
      });
      const end = () => {
        if (!drawing) return;
        drawing = false;
        this._save();
      };
      c.addEventListener('pointerup', end);
      c.addEventListener('pointercancel', end);
      c.addEventListener('pointerleave', end);
    }

    _ink() {
      this._hasInk = true;
      this._hint.classList.add('hidden');
    }

    _draw(dataUrl) {
      const img = new Image();
      img.onload = () => {
        const c = this._canvas;
        const dpr = Math.min(window.devicePixelRatio || 1, 3);
        this._ctx.drawImage(img, 0, 0, c.width / dpr, c.height / dpr);
        this._ink();
      };
      img.src = dataUrl;
    }

    _save() {
      try { localStorage.setItem(KEY(this._id), this._canvas.toDataURL('image/png')); } catch (e) {}
    }

    _restore() {
      let v = null;
      try { v = localStorage.getItem(KEY(this._id)); } catch (e) {}
      if (v) this._draw(v);
    }

    clear() {
      const c = this._canvas;
      const dpr = Math.min(window.devicePixelRatio || 1, 3);
      this._ctx.clearRect(0, 0, c.width / dpr, c.height / dpr);
      this._hasInk = false;
      this._hint.classList.remove('hidden');
      try { localStorage.removeItem(KEY(this._id)); } catch (e) {}
    }
  }

  customElements.define('signature-pad', SignaturePad);
})();
